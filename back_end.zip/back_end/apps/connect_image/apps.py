# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class ConnectImageConfig(AppConfig):
    name = 'connect_image'
