# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class GraphElementConfig(AppConfig):
    name = 'graph_element'
